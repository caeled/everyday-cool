# Language: polish
# File ending: pl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

# common to many functions [Set 1]
1.1:\n
# main [Set 1] 
1.2:Wykaz �CIE�KI katalog�w\n
# Must include %s for label 
1.3:Wykaz �CIE�KI katalog�w dla woluminu %s\n
# Must include %s for serial #  
1.4:Numer seryjny woluminu to %s\n
1.5:Nie ma podkatalog�w\n\n
# showUsage [Set 2] 
2.1:Graficznie wy�wietla struktur� katalog�w nap�du lub �cie�ki.\n
# Each %c below will be replaced with proper switch/option
2.2:TREE [nap�d:][�cie�ka] [%c%c] [%c%c]\n
2.3:   %c%c   Wy�wietla nazwy plik�w w ka�dym katalogu.\n
2.4:   %c%c   U�yj ASCII zamiast znak�w rozszerzonych.\n
# showInvalidUsage [Set 3] 
# Must include the %s for option given.
3.1:Nieprawid�owa opcja - %s\n
# The %c will be replaced with the primary switch (default is /)
3.2:U�yj TREE %c?, aby uzyska� informacje o u�yciu.\n
#showTooManyOptions
3.3:Zbyt wiele parametr�w - %s\n
# showVersionInfo [Set 4] 
# also uses treeDescription, message 2.1
4.1:Napisany do pracy z FreeDOS\n
4.2:Konsola Win32(c) i DOS z obs�ug� LFN.\n
# Must include the %s for version string. 
4.3:Wersja %s\n
4.4:Autor:       Kenneth J. Davis\n
4.5:Data:        sierpie�-listopad 2000; stycze� 2001\n
4.6:Kontakt:     jeremyd@computer.org\n
4.7:Copyright (c): Public Domain [definicja USA]\n
#4.8 is only used when cats support is compiled in.
4.8:U�ywa biblioteki Cats Jima Halla <jhall@freedos.org>\n  Copyright (C) 1999,2000,2001 Jim Hall\n
#4.20 20-30 reserved for FreeDOS tree derived from Dave Dunfield's tree
4.20:Copyright 1995, 2000 Dave Dunfield - swobodna dystrybucja (GPL w 2000).\n
# showInvalidDrive [Set 5] 
5.1:Nieprawid�owa specyfikacja nap�du\n
# showInvalidPath [Set 6] 
# Must include %s for the invalid path given. 
6.1:Nieprawid�owa �cie�ka - %s\n
# misc error conditions [Set 7]
# showBufferOverrun
# %u required to show what the buffer's current size is. 
7.1:B��d: Podana �cie�ka przekracza limit bufora = %u bajt�w\n
# showOutOfMemory
# %s required to display what directory we were processing when ran out of memory.
7.2:Brak pami�ci w podkatalogu: %s\n
#
# parseArguments [Set 8]
8.1:/
8.2:-
8.3:F
8.4:f
8.5:A
8.6:a
8.7:V
8.8:v
8.9:S
8.10:s
