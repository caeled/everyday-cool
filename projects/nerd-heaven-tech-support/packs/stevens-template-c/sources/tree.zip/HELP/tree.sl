# Language: slovenian
# File ending: sl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

To je datoteka readme za program FreeDOS TREE.

Grafi�no prika�e strukturo map pogona ali poti.

Uporaba:  TREE [/A] [/F] [POT]
  /A    Uporabi znake ASCII za risanje �rt.
  /F    Prika�e datoteke v imenikih (namesto samo imenikov).
  POT   Kje za�eti prikazovati drevo imenikov, privzeto je
        trenutni imenik.

Ta program ima mednarodno podporo z uporabo knji�nice "Cats"
(implementacija catopen/catgets za DOS). "Cats" lahko prenesete s strani
http://www.freedos.org/jhall/cats

TREE se distribuira pod licenco GNU GPL. Za podrobnosti glejte datoteko
COPYING.
