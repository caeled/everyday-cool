# Language: polish
# File ending: pl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

To jest plik readme programu FreeDOS TREE.

Graficznie wy�wietla struktur� folder�w nap�du lub �cie�ki.

U�ycie:  TREE [/A] [/F] [�CIE�KA]
  /A    U�yj znak�w ASCII do rysowania linii.
  /F    Wy�wietla pliki w katalogach (zamiast samych katalog�w).
  �CIE�KA Gdzie zacz�� wy�wietlanie drzewa katalog�w, domy�lnie jest
        to bie��cy katalog.

Ten program posiada wsparcie mi�dzynarodowe przy u�yciu biblioteki "Cats"
(implementacja catopen/catgets dla DOS). Mo�esz pobra� "Cats" z
http://www.freedos.org/jhall/cats

TREE jest dystrybuowany na licencji GNU GPL. Szczeg��y znajduj� si� w
pliku COPYING.
