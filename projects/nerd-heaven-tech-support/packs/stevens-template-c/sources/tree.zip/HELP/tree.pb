# Language: brazilian
# File ending: pb
# Codepage: 858
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

Este � o arquivo readme para o programa TREE do FreeDOS.

Exibe graficamente a estrutura de pastas de uma unidade ou caminho.

Uso:  TREE [/A] [/F] [CAMINHO]
  /A    Usa caracteres ASCII para desenho de linhas.
  /F    Exibe arquivos nos diret�rios (em vez de apenas diret�rios).
  CAMINHO Onde come�ar a exibir a �rvore de diret�rios, o padr�o � o
        diret�rio atual.

Este programa tem suporte internacional usando a biblioteca "Cats"
(implementa��o catopen/catgets para DOS). Voc� pode baixar "Cats" de
http://www.freedos.org/jhall/cats

TREE � distribu�do sob a GNU GPL. Veja o arquivo COPYING para detalhes.
