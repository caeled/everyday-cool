# Language: slovenian / slowenisch
# File ending: sl
# Codepage: 852
# Translation made by Google Gemini
# This translation was made by Google AI, please help the FreeDOS group
# to improve it.

0.0:LABEL Razli�ica %s\n
0.1:Ustvari, spremeni ali izbri�e oznako nosilca diska.\n
0.2:Sintaksa: LABEL [pogon:][oznaka] [/?]\n
0.3: [pogon:] Dolo�a, kateri pogon �elite ozna�iti\n
0.4: [oznaka] Dolo�a novo oznako, s katero �elite ozna�iti pogon\n
0.5: /? Prika�e to sporo�ilo za pomo�\n
1.0:Izbri�i trenutno oznako nosilca (D/N)?
1.1:Oznaka nosilca (11 znakov, ENTER za nobeno)?
1.2:Nosilec v pogonu %c nima oznake\n
1.3:Nosilec v pogonu %c je %s\n
1.4:Serijska �tevilka nosilca je %04X-%04X\n
2.0:Neveljaven parameter - /%c\n
2.1:Oznaka je predolga. Oznaka mora\nimeti 11 znakov ali manj.\n
2.2:Neveljavna oznaka nosilca\n
2.3:Omenjenih je bilo ve� pogonov.\nProsimo, izberite en pogon za ozna�evanje hkrati.\n
2.4:Neveljavna oznaka\n
2.5:Ni veljaven pogon\n
2.6:Ne morete ozna�iti omre�nega pogona\n
2.7:Ne morete ozna�iti pogona, ki je bil\nASSIGNiran, JOINiran ali SUBSTiran.\n
2.8:Neveljaven pogon\n
