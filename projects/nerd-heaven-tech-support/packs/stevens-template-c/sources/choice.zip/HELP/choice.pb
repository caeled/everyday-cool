NOME

   CHOICE - Espera o usu�rio apertar uma tecla, de uma lista de op��es

SYNOPSIS

   CHOICE [/B] [/C[:]choices] [/N] [/S] [/T[:]c,nn] [text]

OPTIONS

 /B
    Emite um alerta (bipe) no prompt.

 /C[:]choices
    Especifica as teclas permitidas no prompt. Quando exibido, as
    chaves ser�o separadas por v�rgulas, aparecer�o entre colchetes
    ([]), e ser�o seguidas por um sinal de interroga��o. Se voc� n�o
    especificar a op��o /C, CHOICE usar� YN como padr�o. O dois-pontos
    � opcional.

 /N
   Faz com que CHOICE n�o exiba o prompt. Por�m, o texto anterior ao
   prompt ainda � exibido. Se voc� especificar o /N, as chaves
   especificadas ainda s�o v�lidas.

 /S
   Faz com que CHOICE aja sens�vel ao caso. Se a op��o /S n�o �
   especificada, CHOICE aceitar� tanto caso mai�sculo quanto min�sculo
   das chaves que o usu�rio especificar.

 /T[:]c,nn
     Faz com que CHOICE pause por um n�merp especificado de segundos
     antes de usar uma chave como padr�o. Os valores da op��o /T s�o
     como se segue:

       c   Especifica o caractere a ser exibido ap�s nn segundos. O
           caractere deve estar no conjunto de escolhas especificado
           pela op��o /C.

       nn  Especifica o n�mero de segundos pausado. Valores aceit�veis
           v�o de 0 a 99. Se 0 � especificado, n�o haver� pausa antes
           da inser��o da chave padr�o.

   texto
     Texto a ser exibido como prompt.

VALOR DE RETORNO

   ERRORLEVEL recebe o posicionamento (offset) da op��o que o usu�rio
   selecionou.

AUTOR

   Jim Hall, jhall@freedos.org

