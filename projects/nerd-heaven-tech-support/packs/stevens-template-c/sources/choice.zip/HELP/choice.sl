# Language: Slovenian
# File ending: SL
# Codepage: 852
# This translation was made by Google Gemini.
# Please help the FreeDOS group to improve it.

IME

   CHOICE - Po�aka, da uporabnik pritisne tipko s seznama izbir

POVZETEK

   CHOICE [/B] [/C[:]izbire] [/N] [/S] [/T[:]c,nn] [besedilo]

MO�NOSTI

 /B
    Ob pozivu odda zvo�ni signal (pisk).

 /C[:]izbire
    Dolo�i dovoljene tipke v pozivu. Pri prikazu bodo tipke lo�ene z
    vejicami, pojavile se bodo v oglatih oklepajih ([]) in sledil jim
    bo vpra�aj. �e stikala /C ne dolo�ite, choice privzeto uporabi YN.
    Dvopi�je (:) je neobvezno.

 /N
   Povzro�i, da choice ne prika�e poziva. Besedilo pred pozivom se
   vendarle prika�e. �e dolo�ite stikalo /N, so dolo�ene tipke �e
   vedno veljavne.

 /S
   Povzro�i, da choice razlikuje med velikimi in malimi �rkami. �e
   stikalo /S ni dolo�eno, choice sprejme tako velike kot male �rke
   tipk, ki jih dolo�i uporabnik.

 /T[:]c,nn
     Povzro�i, da choice po�aka dolo�eno �tevilo sekund, preden
     izbere privzeto dolo�eno tipko. Vrednosti za stikalo /T so
     naslednje:

       c   Dolo�i znak, ki se prika�e po nn sekundah. Znak mora
           biti v naboru izbir, dolo�enih s stikalom /C.

       nn  Dolo�i �tevilo sekund za premor. Sprejemljive vrednosti
           so od 0 do 99. �e je dolo�eno 0, pred izbiro privzete
           tipke ne bo premora.

   besedilo
     Niz poziva za prikaz

POVRATNA VREDNOST

   ERRORLEVEL se nastavi na odmik tipke, ki jo uporabnik pritisne v izbirah.

AVTOR

   Jim Hall, jhall@freedos.org

