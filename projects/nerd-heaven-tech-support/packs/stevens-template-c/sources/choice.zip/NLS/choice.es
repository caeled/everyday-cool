# spanisch, es, cp858

0.0:Espera la contestaci�n de un usuario a un grupo de opciones
0.1:opciones
0.2:texto
0.3:Especifica las teclas admisibles. Por omisi�n:
0.4:No mostrar las opciones tras el indicador de espera
0.5:Diferenciar entre may�sculas/min�sculas
0.6:Elegir autom�ticamente la tecla c tras nn segundos
0.7:Texto que se mostrar� con el indicador de espera
0.8:Emitir una alerta sonora al iniciar la espera
0.9:Sintaxis de tiempo de espera incorrecta. Se esperaba Tc,nn o T:c,nn
0.10:Tiempo de espera por defecto no especificado en la opci�n (por omisi�n)
3.0:sn
