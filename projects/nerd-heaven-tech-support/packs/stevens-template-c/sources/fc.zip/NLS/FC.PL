# Language: polish
# File ending: pl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.
1.0:Por�wnuje dwa pliki lub zestawy plik�w i wy�wietla r��nice mi�dzy nimi
1.1:FC [opcje] [dysk1:][�cie�ka1]plik1 [dysk2:][�cie�ka2]plik2 [opcje]
1.2: /A    Wy�wietlaj tylko pierwsz� i ostatni� lini� dla ka�dego zestawu r��nic
1.3: /B    Wykonaj por�wnanie binarne
1.4: /C    Ignoruj wielko�� liter
1.5: /L    Por�wnuj pliki jako tekst ASCII
1.6: /Mn   Ustaw maksymaln� liczb� r��nic w por�wnaniu binarnym na n bajt�w
1.7:       (domy�lnie = %d, 0 = nieograniczona, /M = /M0)
1.8: /N    Wy�wietlaj numery linii przy por�wnaniu tekstowym
1.9: /S    Rozszerz skanowanie na pliki w podkatalogach
1.10: /T    Nie zamieniaj tabulator�w na spacje
1.11: /W    Kompresuj bia�e znaki (tabulacje i spacje) przy por�wnaniu tekstowym
1.12: /X    Nie pokazuj linii kontekstowych w por�wnaniu tekstowym
1.13: /LBn  Ustaw maks. liczb� kolejnych r��nych linii ASCII na n
1.14: /nnn  Ustaw min. liczb� kolejnych pasuj�cych linii na nnn
1.15:       dla resynchronizacji por�wnania
1.16: /R    Poka� kr�tki raport ko�cowy (zawsze aktywny przy u�yciu /S)
1.17: /Q    Nie pokazuj listy r��nic
1.18: /U    Poka� nazwy plik�w bez odpowiednika
#### Messages    ####
2.0:Nieprawid�owa opcja: %s
2.1:Zbyt wiele specyfikacji plik�w
2.2:Nieprawid�owa nazwa pliku
2.3:Nie okre�lono pliku
2.4:Ostrze�enie: pliki maj� r��n� wielko��!
2.5:Por�wnywanie przerwane po %d niezgodno�ciach
2.6:Brak r��nic
2.7:Ostrze�enie: por�wnywanie przerwane po %d liniach
2.8:Niewystarczaj�ca ilo�� pami�ci
2.9:B��d podczas otwierania pliku %s
2.10:Por�wnywanie %s i %s
2.11:Nie ma takiego pliku ani katalogu
2.12:Resynchronizacja nieudana: pliki zbyt r��ne
2.13:Pliki maj� r��n� wielko��
2.14:Pliki r��ni� si� od siebie
2.15:Plik %s nie ma odpowiednika (%s)
#### Report text ####
3.0:Por�wnano %d plik�w
3.1: w %d katalogach
3.2:%d plik�w jest zgodnych, %d plik�w r��ni si�
3.3:%d plik�w nie ma odpowiednika
