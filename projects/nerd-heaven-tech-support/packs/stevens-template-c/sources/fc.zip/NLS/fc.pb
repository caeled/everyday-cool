# Language: brazilian
# File ending: pb
# Codepage: 858
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.
1.0:Compara dois arquivos ou conjuntos de arquivos e exibe as diferen�as
1.1:FC [op��es] [unid1:][pfad1]arq1 [unid2:][pfad2]arq2 [op��es]
1.2: /A    Exibir apenas primeira e �ltima linha para cada conjunto de diferen�as
1.3: /B    Realizar uma compara��o bin�ria
1.4: /C    Desconsiderar mai�sculas/min�sculas
1.5: /L    Comparar arquivos como texto ASCII
1.6: /Mn   Definir o m�ximo de diferen�as na compara��o bin�ria para n bytes
1.7:       (padr�o = %d, 0 = ilimitado, /M = /M0)
1.8: /N    Exibir os n�meros de linha em uma compara��o de texto
1.9: /S    Estender a busca para arquivos em subdiret�rios
1.10: /T    N�o expandir tabs para espa�os
1.11: /W    Compactar espa�os em branco (tabs e espa�os) para compara��o de texto
1.12: /X    N�o exibir linhas de contexto na compara��o de texto
1.13: /LBn  Definir o n�mero m�ximo de linhas ASCII consecutivas diferentes para n
1.14: /nnn  Definir o n�mero m�nimo de linhas consecutivas iguais para nnn
1.15:       para ressincroniza��o da compara��o
1.16: /R    Mostrar um relat�rio final breve (sempre ativo ao usar /S)
1.17: /Q    N�o exibir a lista de diferen�as
1.18: /U    Exibir os nomes dos arquivos sem um correspondente
#### Messages    ####
2.0:Op��o inv�lida: %s
2.1:Muitas especifica��es de arquivo
2.2:Nome de arquivo inv�lido
2.3:Nenhum arquivo especificado
2.4:Aviso: os arquivos t�m tamanhos diferentes!
2.5:Compara��o interrompida ap�s %d diverg�ncias
2.6:Nenhuma diferen�a encontrada
2.7:Aviso: compara��o interrompida ap�s %d linhas
2.8:Mem�ria insuficiente
2.9:Erro ao abrir arquivo %s
2.10:Comparando %s e %s
2.11:Arquivo ou diret�rio n�o encontrado
2.12:Falha na ressincroniza��o: arquivos muito diferentes
2.13:Os arquivos t�m tamanhos diferentes
2.14:Os arquivos s�o diferentes
2.15:O arquivo %s n�o tem correspondente (%s)
#### Report text ####
3.0:Comparados %d arquivos
3.1: em %d diret�rios
3.2:%d arquivos iguais, %d arquivos diferentes
3.3:%d arquivos n�o possuem correspondente
