# Language: polish
# File ending: pl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

FC v. 3.03 (c) 2004 Maurizio Spagni

FC por�wnuje dwa pliki lub zestawy plik�w, w trybie tekstowym lub binarnym,
i wy�wietla r��nice mi�dzy nimi.

FC implementuje algorytm Paula Heckela z Communications of the
Association for Computing Machinery, kwiecie� 1978, str. 264 - 268,
"A Technique for Isolating Differences Between Files".

Ten algorytm ma t� przewag� nad powszechnie stosowanymi algorytmami, �e
jest szybki i wykrywa r��nice przy dowolnej liczbie linii. W wi�kszo�ci
zastosowa� izoluje r��nice podobnie do algorytmu najd�u�szego wsp�lnego
podci�gu.

Sk�adnia jest nast�puj�ca:

FC [opcje] [dysk1:][�cie�ka1]plik1 [dysk2:][�cie�ka2]plik2 [opcje]

 /A    Wy�wietl tylko pierwsz� i ostatni� lini� dla ka�dego zestawu r��nic
 /B    Wykonaj por�wnanie binarne
 /C    Ignoruj wielko�� liter
 /L    Por�wnuj pliki jako tekst ASCII
 /LBn  Ustaw maks. liczb� kolejnych r��nych linii ASCII na n
 /Mn   Ustaw maks. liczb� r��nic w por�wnaniu binarnym na n bajt�w
 /N    Wy�wietlaj numery linii przy por�wnaniu tekstowym
 /Q    Nie pokazuj listy r��nic
 /R    Poka� kr�tki raport ko�cowy (zawsze aktywny przy u�yciu /S)
 /S    Rozszerz skanowanie na pliki w podkatalogach
 /T    Nie zamieniaj tabulator�w na spacje
 /U    Poka� nazwy plik�w bez odpowiednika
 /W    Kompresuj bia�e znaki (tabulacje i spacje) przy por�wnaniu tekstowym
 /X    Nie pokazuj linii kontekstowych w por�wnaniu tekstowym
 /nnn  Ustaw min. liczb� kolejnych pasuj�cych linii na nnn
       dla resynchronizacji por�wnania

Program obs�uguje d�ugie nazwy plik�w (LFN) i u�ywa ich automatycznie,
je�li system operacyjny je wspiera.

FC domy�lnie u�ywa trybu binarnego dla plik�w .EXE, .COM, .SYS, .OBJ,
.BIN, .DLL i .LIB.

W trybie binarnym FC pokazuje offset w pliku dla r��ni�cych si� bajt�w,
ich warto�� szesnastkow� oraz znak ASCII (je�li jest drukowalny).

Domy�lnie por�wnanie binarne ko�czy si� po 20 r��nicach, ale mo�na to
zmieni� opcj� /M. /M0 oznacza "brak limitu". /M jest traktowane jako /M0.

Ograniczeniem programu w trybie tekstowym jest por�wnywanie tylko
pierwszych 32765 linii; pozosta�e s� ignorowane. D�ugo�� linii jest
praktycznie nieograniczona.

FC obs�uguje symbole wieloznaczne (wildcards). Kilka uwag:
- podanie katalogu jest to�same z wybraniem wszystkich plik�w ("*.*").
  Przyk�ad: "FC C:\ A:" to samo co "FC C:\*.* A:*.*"
- brak pliku2 oznacza "." (bie��cy katalog).
  Przyk�ad: "FC C:\PLIK.TXT" to samo co "FC C:\PLIK.TXT .\*.*"
- je�li plik1 ma symbole wieloznaczne, a plik2 nie, pliki pasuj�ce do
  plik1 s� por�wnywane z tym samym plikiem2.
- je�li plik1 ma symbole wieloznaczne, a plik2 to �cie�ka z "*.*", pliki
  z plik1 s� por�wnywane z plikami o tej samej nazwie w �cie�ce plik2.
- je�li oba maj� symbole wieloznaczne, pliki ze �cie�ki plik1 s�
  por�wnywane z odpowiednimi plikami w �cie�ce plik2.
  Przyk�ad: "FC *.TXT STARE\*.BAK"
To prostsze w dzia�aniu ni� w opisie. Aby por�wna� ka�dy plik w katalogu
z wszystkimi w innym: FC *.* MOJKAT\????????.???

Opcja /S powtarza ten sam wzorzec wyszukiwania w podkatalogach o tej samej
nazwie w obu �cie�kach.
  Przyk�ad: "FC /S C:*.TXT D:*.BAK"
  Przy istnieniu katalog�w C:\KSIAZKA i D:\KSIAZKA, polecenie por�wna
  pliki *.TXT w bie��cych katalogach oraz w podkatalogach KSIAZKA.

Kody wyj�cia ERRORLEVEL:
	0	Wszystkie pliki s� zgodne
	1	Co najmniej jedna para plik�w r��ni si�
	2	Nieprawid�owy parametr w linii polece�
	3	Nie znaleziono pliku
	4	B��d podczas otwierania plik�w
