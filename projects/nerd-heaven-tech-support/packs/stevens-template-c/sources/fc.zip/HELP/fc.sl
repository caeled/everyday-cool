# Language: slovenian
# File ending: sl
# Codepage: 852
# This translation was made by Google AI,
# please help the FreeDOS group to improve it.

FC v. 3.03 (c) 2004 Maurizio Spagni

FC primerja dve datoteki ali niza datotek v tekstovnem ali binarnem na�inu
ter prika�e razlike med njima.

FC uporablja algoritem Paula Heckla iz Communications of the Association
for Computing Machinery, april 1978, str. 264 - 268,
"A Technique for Isolating Differences Between Files".

Ta algoritem je hitrej�i od obi�ajnih algoritmov in lahko zazna razlike
pri poljubnem �tevilu vrstic. V ve�ini primerov algoritem izolira razlike
podobno kot metoda najdalj�ega skupnega podzaporedja.

Sintaksa je naslednja:

FC [mo�nosti] [pogon1:][pot1]datoteka1 [pogon2:][pot2]datoteka2 [mo�nosti]

 /A    Prika�i le prvo in zadnjo vrstico za vsak sklop razlik
 /B    Izvedi binarno primerjavo
 /C    Prezri razlikovanje med velikimi in malimi �rkami
 /L    Primerjaj datoteke kot besedilo ASCII
 /LBn  Nastavi maks. �tevilo zaporednih razli�nih vrstic ASCII na n
 /Mn   Nastavi maks. �tevilo razlik v binarni primerjavi na n bajtov
 /N    Prika�i �tevilke vrstic pri tekstovni primerjavi
 /Q    Ne prika�i seznama razlik
 /R    Prika�i kratko kon�no poro�ilo (vedno aktivno pri uporabi /S)
 /S    Raz�iri iskanje na datoteke v podimenikih
 /T    Ne raz�iri tabulatorjev v presledke
 /U    Prika�i imena datotek brez ustrezne datoteke na drugi strani
 /W    Strni prazne prostore (tabulatorje in presledke) za primerjavo
 /X    Ne prika�i kontekstnih vrstic pri tekstovni primerjavi
 /nnn  Nastavi min. �tevilo zaporednih ujemajo�ih se vrstic na nnn
       za ponovno sinhronizacijo primerjave

Program podpira dolga imena datotek (LFN) in jih uporablja samodejno, �e
jih operacijski sistem podpira.

FC privzeto uporablja binarni na�in za datoteke .EXE, .COM, .SYS, .OBJ,
.BIN, .DLL in .LIB.

V binarnem na�inu FC prika�e odmik (offset) v datoteki za razli�ne bajte,
njihovo �estnajsti�ko vrednost in znak ASCII (�e ga je mogo�e natisniti).

Privzeto se binarna primerjava ustavi po 20 razlikah, vendar lahko to
vrednost spremenite s stikalom /M. /M0 pomeni "neomejeno".
/M se obravnava kot /M0.

Omejitev programa je, da se v tekstovnem na�inu primerja le prvih 32765
vrstic; ostale vrstice so prezrte. Dol�ina vrstice je neomejena.

FC podpira nadomestne znake (wildcards). Nekaj pojasnil:
- navedba imenika je isto kot navedba vseh datotek v njem ("*.*").
  Primer: "FC C:\ A:" je enako kot "FC C:\*.* A:*.*"
- �e datoteka2 ni vnesena, se privzame "." (trenutni imenik).
  Primer: "FC C:\TEST.TXT" je enako kot "FC C:\TEST.TXT .\*.*"
- �e ima datoteka1 nadomestne znake, datoteka2 pa ne, se vse datoteke,
  ki ustrezajo datoteki1, primerjajo z isto datoteko2.
- �e ima datoteka1 nadomestne znake, datoteka2 pa je pot z "*.*", se
  datoteke iz datoteka1 primerjajo z datotekami z istim imenom na poti2.
- �e imata obe nadomestne znake, se datoteke na poti datoteka1 primerjajo
  z ustreznimi datotekami na poti datoteka2.
  Primer: "FC *.TXT STARE\*.BAK"
To je la�je storiti kot razlo�iti. �e �elite primerjati vsako datoteko v
imeniku z vsemi v drugem: FC *.* MOJDIR\????????.???

Mo�nost /S ponovi isti vzorec iskanja v podimenikih z istim imenom.
  Primer: "FC /S C:*.TXT D:*.BAK"
  �e obstajata npr. C:\KNJIGA in D:\KNJIGA, ta ukaz primerja vse *.TXT
  v trenutnih imenikih in tudi v podimenikih KNJIGA.

Izhodne kode ERRORLEVEL so:
	0	Vse datoteke se ujemajo
	1	Vsaj en par datotek se razlikuje
	2	Neveljaven parameter v ukazni vrstici
	3	Datoteka ni bila najdena
	4	Napaka pri odpiranju datotek
