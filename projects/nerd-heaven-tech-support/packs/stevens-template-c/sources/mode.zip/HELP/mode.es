# Language: Spanish
# File ending: ES
# Codepage: 858
# This translation was made by Google Gemini.
# Please help the FreeDOS group to improve it.

	Documentaci�n de uso del programa Free-DOS MODE

	(c) Copyright 1994-1995 por K. Heidenstrom.

	Modificado:

	KH.19941231.001  (MODE 1.0.0)  Primera versi�n
	KH.19950116.002  (MODE 1.0.2)  A�adida documentaci�n de switchar
	KH.19950520.003  (MODE 1.0.3)  Sin cambios en la funcionalidad
	KH.19950805.004  (MODE 1.0.4)  A�adidas opciones de modificadores (shift-state)


1.  LEGAL

	Este programa es Copyright 1994-1995 por K. Heidenstrom. Fue escrito
	espec�ficamente para el proyecto Free-DOS. El autor puede ser contactado
	en kheidens@actrix.gen.nz en Internet o por correo postal:
	K. Heidenstrom c/- P.O. Box 27-103, Wellington, New Zealand.

	Este programa es software libre. Puede redistribuir el c�digo fuente y
	el ejecutable y/o modificar el programa bajo los t�rminos de la GNU
	General Public License tal como fue publicada por la Free Software
	Foundation; ya sea la versi�n 2 de la Licencia, o (a su elecci�n)
	cualquier versi�n posterior.

	Este programa se distribuye con la esperanza de que sea �til, pero
	se proporciona "tal cual", sin ninguna garant�a de ning�n tipo,
	incluida la garant�a impl�cita de comerciabilidad o idoneidad para un
	prop�sito particular. En ning�n caso el autor ser� responsable de
	da�os de ning�n tipo relacionados con el uso de este programa. Vea la
	GNU General Public License para m�s detalles.

	Deber�a haber recibido una copia de la GNU General Public License junto
	con este programa; si no es as�, escriba a la Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

2.  FUNCIONES Y SINTAXIS DE USO

	El programa MODE realiza seis funciones independientes, que se
	describen por separado a continuaci�n.

2.1.  ESTABLECER MODO DE V�DEO Y N�MERO DE L�NEAS DE PANTALLA

	MODE permite establecer el modo de v�deo en uno de cinco modos. La
	sintaxis es:

	MODE Videomodo[,L�neas]

	Los modos son:

	MONO	Modo monocromo, tal como se usa con las tarjetas MDA y Hercules,
		y tambi�n emulado en tarjetas EGA y VGA. Este modo es el �nico
		que tiene la capacidad de subrayar caracteres en la pantalla de
		forma predeterminada. Este modo no puede seleccionarse en la
		tarjeta de v�deo CGA.

	BW40	Modo de 40 columnas con color suprimido. Este modo es espec�fico
		del adaptador CGA y ofrece una pantalla de 40 columnas por 25
		l�neas. La informaci�n de color de la se�al de v�deo compuesto
		de la tarjeta CGA se desactiva, de modo que la pantalla se ve
		en blanco y negro en un monitor de color compuesto, con
		diecis�is tonos de gris.
		Si se selecciona este modo en una tarjeta EGA o VGA, o en una
		tarjeta CGA que no est� conectada a un televisor o a un monitor
		de color compuesto, aparecer� igual que el modo CO40 (es decir,
		el color no se suprimir�). Este modo no puede seleccionarse en
		tarjetas de v�deo MDA y Hercules.

	BW80	Modo de 80 columnas con color suprimido. Este modo tambi�n es
		espec�fico del adaptador CGA y es igual al BW40 excepto que hay
		80 columnas.
		Si se selecciona este modo en una tarjeta EGA o VGA, o en una
		tarjeta CGA que no est� conectada a un televisor o a un monitor
		de color compuesto, aparecer� igual que el modo CO80 (es decir,
		el color no se suprimir�). Este modo no puede seleccionarse en
		tarjetas de v�deo MDA y Hercules.

	CO40	Modo de color de 40 columnas. Este modo ofrece una pantalla en
		color de 40 columnas por 25 l�neas. Es compatible con los
		adaptadores CGA, EGA y VGA, pero no con las tarjetas MDA y
		Hercules.

	CO80	Modo de color de 80 columnas. Este modo ofrece una pantalla de
		80 columnas por 25 l�neas y es el modo de visualizaci�n normal
		para las tarjetas CGA, EGA y VGA. No es compatible con las
		tarjetas MDA y Hercules. En las tarjetas EGA, este modo tambi�n
		admite una variante de 43 l�neas, y en las tarjetas VGA, se
		admiten la variante de 43 l�neas y una de 50 l�neas.

		Los modos de 43 y 50 l�neas pueden seleccionarse especificando
		",43" o ",50" despu�s de CO80 en la l�nea de comandos de MODE.
		Si no se especifica este par�metro, se utilizar� el valor
		predeterminado de 25 l�neas.

	Una vez establecido, el modo de v�deo permanecer� en vigor hasta que se
	cambie mediante un comando MODE o por un programa. El modo de v�deo no
	est� bloqueado permanentemente: los programas son libres de cambiar
	los modos de v�deo seg�n lo requieran.

2.2.  CONFIGURAR PAR�METROS DEL PUERTO SERIE

	MODE permite configurar los par�metros de comunicaci�n de un puerto
	serie. La sintaxis es:

	MODE COMn:r,p,d,s

	n	Especifica qu� puerto serie se va a configurar, en el rango de
		1 a 4. Si el puerto serie no existe, MODE informar� de un error.

	r	Especifica la velocidad de baudios en bits por segundo. Los
		valores son: 50, 110, 150, 300, 600, 1200, 2400, 4800, 9600,
		14400, 19200, 28800, 38400, 57600 y 115200.

		1200, 2400, 4800 y 9600 pueden abreviarse como 12, 24, 48 y 96
		respectivamente. 14400, 19200, 28800, 38400 y 57600 pueden
		abreviarse a sus primeros dos o tres d�gitos. 115200 puede
		abreviarse como 115 o 1152.

	p	Especifica el tipo de paridad generada y comprobada en los
		bytes de datos. Los valores son:

		E = Paridad par (Even)
		O = Paridad impar (Odd)
		N = Sin paridad (No parity)

	d	Especifica el n�mero de bits de datos que se transmitir�n y
		recibir�n. Los valores permitidos son 5, 6, 7 y 8.

	s	Especifica el n�mero de bits de parada que se transmitir�n y
		se esperar�n. Puede ser 1 o 2. Si se usan 2 bits de parada en
		conjunci�n con 5 bits de datos, el puerto serie generar� y
		comprobar� realmente 1 1/2 bits de parada.

	Una vez establecidos, los par�metros del puerto serie permanecer�n en
	vigor hasta que se cambien por un comando MODE o por un programa.
	Los ajustes del puerto serie no est�n bloqueados permanentemente: los
	programas son libres de cambiarlos seg�n lo requieran.

2.3.  REDIRECCI�N DE PUERTO PARALELO Y REINTENTOS INFINITOS

	MODE permite redireccionar la salida del puerto paralelo (LPT) a un
	puerto serie (COM), a NUL (es decir, a nada), y tambi�n puede
	reintentar indefinidamente si el perif�rico no responde.

	Estas funciones las realiza la parte residente de MODE, que se
	instalar� autom�ticamente si es necesario cuando se solicite la
	funci�n.

	La sintaxis es:

	MODE LPTn:P		Tiempo de espera infinito en puerto paralelo
	MODE LPTn:=COMx		Redireccionar salida de impresora a puerto COM
	MODE LPTn:=NUL:		Redireccionar salida de impresora a NUL
	MODE LPTn:		Eliminar redirecci�n y tiempo de espera infinito

	La funci�n LPTn:P especifica reintentos infinitos en caso de tiempo
	de espera agotado. Si esto est� habilitado, MODE reintentar�
	continuamente si la impresora no responde. Si no est� habilitado, y la
	impresora no responde en un cierto per�odo de tiempo (normalmente
	alrededor de medio minuto), se informar� de un error de escritura.

	Las funciones LPTn:=COMx y LPTn:=NUL: especifican la redirecci�n de
	la salida de la impresora. Cualquier puerto paralelo (exista o no)
	puede ser redireccionado a cualquier puerto serie existente, o a NUL.
	Se puede redireccionar m�s de un puerto paralelo al mismo puerto serie
	o a NUL. Estas funciones son �tiles si tiene una impresora serie, o
	si no tiene impresora y desea evitar que el ordenador se bloquee si un
	programa intenta imprimir en una impresora inexistente.

	La funci�n LPTn: elimina cualquier redirecci�n y tiempo de espera
	infinito que pueda estar configurado para el puerto especificado, y
	lo devuelve al funcionamiento normal.

2.4.  FUNCIONES DE APARCAMIENTO DE DISCO DURO (PARK)

	MODE aparcar� el disco duro o los discos duros (solo los dos primeros
	discos duros f�sicos del sistema), ya sea inmediatamente o despu�s de
	que el disco haya estado inactivo durante un per�odo de tiempo.

	La funci�n de aparcamiento temporizado la realiza la parte residente
	de MODE, que se instalar� autom�ticamente si es necesario cuando se
	solicite la funci�n.

	La sintaxis es:

	MODE PARK			Aparcar ahora
	MODE PARK,minutos[:segundos]	Aparcar tras inactividad del disco duro

	La funci�n PARK aparca el/los disco(s) duro(s) inmediatamente y espera
	a que apague el ordenador. Tambi�n puede presionar Ctrl-C para salir
	y volver a DOS.

	La funci�n PARK,minutos[:segundos] hace que el/los disco(s) duro(s) se
	aparquen tras un cierto per�odo de inactividad, que puede ser de hasta
	50 minutos. Si tiene dos discos duros f�sicos, ambos se gestionan por
	separado.

	Una vez establecido, puede cambiar el per�odo de tiempo ejecutando el
	comando de nuevo con un valor de tiempo diferente. La funci�n de
	aparcamiento temporizado no se puede desactivar: debe reiniciar para
	eliminarla.

	Estas funciones generalmente solo son �tiles para m�quinas antiguas.
	Los discos duros modernos se aparcan autom�ticamente al apagarse.

2.5.  FUNCIONES TYPEMATIC (REPETICI�N DE TECLADO)

	MODE permite establecer los par�metros de retraso inicial de repetici�n
	y la velocidad de repetici�n de las teclas (typematic), y
	opcionalmente bloquearlos.

	La funci�n de bloqueo de typematic la realiza la parte residente de
	MODE, que se instalar� autom�ticamente si es necesario cuando se
	solicite la funci�n.

	La sintaxis es:

	MODE DELAY=d RATE=r		Establecer par�metros de typematic
	MODE DELAY=d RATE=r LOCK	Establecer y bloquear par�metros

	d	Especifica el retraso inicial, el rango es de 1 a 4 y el
		retraso es de entre 1/4 de segundo (1) y un segundo (4).

	r	Especifica la velocidad de auto-repetici�n. El rango es de 1
		a 32 y la velocidad es de entre dos repeticiones por segundo
		(1) y 30 repeticiones por segundo (32).

	LOCK	Especifica que los par�metros de typematic deben bloquearse.
		Una vez hecho esto, los par�metros pueden cambiarse volviendo
		a ejecutar MODE, pero no pueden ser cambiados por la mayor�a
		de los otros programas. Esto puede ser �til, ya que algunos
		programas cambian los par�metros sin su permiso. No es
		completamente infalible, sin embargo.

	Tenga en cuenta que deben especificarse tanto DELAY como RATE para
	estas funciones.

	MODE no intenta confirmar si el ajuste de typematic est� disponible
	en la m�quina. MODE aceptar� todos los comandos de typematic, tanto
	si la m�quina los admite realmente como si no.

2.6.  FUNCIONES SWITCHAR

	MODE puede mostrar y establecer el car�cter de interruptor de DOS
	(switchar). El switchar predeterminado es la barra inclinada, '/'. El
	switchar es el car�cter que se utiliza para indicar el inicio de un
	interruptor de opci�n, por ejemplo, el interruptor /P para el comando
	DIR. Normalmente, el switchar puede cambiarse a '-'. El switchar es
	una caracter�stica de DOS no documentada que pocos programas
	soportan correctamente.

	La sintaxis es:

	MODE SWITCHAR			Mostrar switchar actual
	MODE SWITCHAR=x			Establecer switchar al car�cter x
	MODE SWITCHAR=n			Establecer switchar al valor ASCII n

	El par�metro SWITCHAR por s� solo hace que MODE muestre el switchar
	actual. El uso de SWITCHAR= establece el switchar. El nuevo switchar
	puede especificarse como un car�cter (p. ej., 'MODE SWITCHAR=/') o
	como un n�mero (p. ej., 'MODE SWITCHAR=45').

2.7.  FUNCIONES DE MODIFICADORES (ESTADO DE SHIFT)

	MODE puede cambiar los tres estados de cambio bloqueables (caps lock,
	numlock y scroll lock). Esta funci�n no debe usarse en m�quinas con
	teclados originales de PC o XT, porque los LED indicadores de estos
	teclados no pueden controlarse desde el ordenador y se desincronizar�n
	con los estados de cambio del ordenador. En ATs y m�quinas
	posteriores, no hay problema.

	La sintaxis de par�metros para este comando consiste en las siguientes
	opciones:

		CAPSLOCK=ON	CAPSLOCK=OFF
		NUMLOCK=ON	NUMLOCK=OFF
		SCRLOCK=ON	SCRLOCK=OFF

	Se permite cualquier combinaci�n no conflictiva y no duplicada de estas
	opciones. Adem�s, SCRLOCK puede expandirse a SCROLLLOCK.

3.  GENERAL

	Los par�metros de MODE no distinguen entre may�sculas y min�sculas.

	MODE solo puede procesar un comando en cada invocaci�n. Si desea
	redireccionar varios puertos LPT, debe usar un comando MODE por
	separado para cada uno. No se pueden combinar comandos de diferentes
	tipos en la l�nea de comandos.

	Los mensajes de error siempre se env�an a StdErr. Los mensajes de
	informaci�n se env�an a la salida est�ndar y pueden redireccionarse a
	NUL: para una operaci�n "silenciosa".

	Los niveles de error (Errorlevels) devueltos por MODE son los
	siguientes:

	0	Sin error
	115	El puerto serie no existe (ya sea para COMn: o LPTn:=COMx)
	117	No se encontraron discos duros para aparcar
	118	El modo de v�deo especificado no es compatible con esta m�quina
	162	Memoria insuficiente (MODE requiere unos 6K de memoria)
	241	Par�metro fuera de rango (p. ej., valor de tiempo, n�mero LPT)
	242	No puede tener modos de 43 o 50 l�neas con modos distintos a CO80
	243	Velocidad de baudios desconocida
	244	Debe especificar tanto DELAY= como RATE= para el ajuste typematic
	246	Se dio m�s de un comando o tipo de comando
	255	Sintaxis de uso incorrecta (todos los errores de sintaxis de uso)

	MODE es un programa TSR. Si es necesario, MODE instalar� parte de s�
	mismo de forma residente en la memoria del ordenador. Esta parte
	residente realiza la redirecci�n de la impresora y el manejo de
	tiempos de espera, el aparcamiento autom�tico de la unidad de disco
	duro y el bloqueo de los par�metros de typematic, y no se puede
	eliminar sin reiniciar (a menos que se usen los programas MARK y
	RELEASE de dominio p�blico). Si se requieren funciones residentes
	adicionales y la parte residente ya est� instalada, MODE habilitar�
	esas funciones en la parte residente en lugar de instalar otra.

	Debido a que MODE es un TSR, puede ser incompatible con aplicaciones
	u otros TSR que pueda estar usando. Si ocurren problemas, intente
	establecer qu� programas est�n en conflicto. Puede ser posible evitar
	el problema instalando los programas en un orden diferente.

	Si encuentra un error en MODE, informe al autor. Los detalles de
	contacto se dan en la secci�n 1 de este documento.

4.  EJEMPLOS DE USO

	Aqu� hay una muestra del uso de MODE en AUTOEXEC.BAT, demostrando
	todas las caracter�sticas:

	mode co80,43			>nul:
	mode com1:96,n,8,1		>nul:
	mode com2:19,n,8,1		>nul:
	mode com3:24,n,8,1		>nul:
	mode lpt1:=com2			>nul:
	mode lpt1:p			>nul:
	mode lpt2:=nul:			>nul:
	mode lpt3:=nul:			>nul:
	mode park,0:30			>nul:
	mode delay=1 rate=32 lock	>nul:
	mode switchar=-			>nul:
	mode numlock=off		>nul:

	Esta secuencia selecciona primero el modo de pantalla en color de 43
	l�neas, luego configura los par�metros del puerto serie para COM1,
	COM2 y COM3 (9600, 19200 y 2400 bps respectivamente, sin paridad,
	ocho bits de datos y un bit de parada).
	Luego, la salida de LPT1 se redirecciona a COM2, de modo que cualquier
	cosa que se imprima en LPT1 se enviar� por COM2 en su lugar, a
	19200 bps (por ejemplo, a una impresora l�ser serie), y LPT2 y LPT3
	se redireccionan a NUL para que cualquier cosa enviada a ellos no
	vaya a ninguna parte.
	Luego se instala un aparcamiento de disco duro temporizado, que
	aparcar� los discos duros tras 30 segundos de inactividad.
	Finalmente, se selecciona y bloquea el retraso m�s corto y la
	velocidad m�s r�pida para la funci�n typematic del teclado, y el
	switchar de DOS se establece en un guion ('-').

				   ----//----
				   
