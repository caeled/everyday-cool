# Language: Slovenian
# File ending: SL
# Codepage: 852
# This translation was made by Google Gemini.
# Please help the FreeDOS group to improve it.

	Dokumentacija za uporabo programa Free-DOS MODE

	(c) Copyright 1994-1995 K. Heidenstrom.

	Spremenjeno:

	KH.19941231.001  (MODE 1.0.0)  Prva razli�ica
	KH.19950116.002  (MODE 1.0.2)  Dodana dokumentacija za switchar
	KH.19950520.003  (MODE 1.0.3)  Brez sprememb v funkcionalnosti
	KH.19950805.004  (MODE 1.0.4)  Dodane mo�nosti modifikatorjev
	(shift-state)


1.  PRAVNA OBVESTILA

	Ta program je Copyright 1994-1995 K. Heidenstrom. Napisan je bil
	posebej za projekt Free-DOS. Avtorja lahko kontaktirate na naslovu
	kheidens@actrix.gen.nz na internetu ali po po�ti:
	K. Heidenstrom c/- P.O. Box 27-103, Wellington, New Zealand.

	Ta program je prosta programska oprema. Virno kodo in izvr�ljivo
	datoteko lahko raz�irjate in/ali spreminjate pod pogoji licence GNU
	General Public License, kot jo je objavila Free Software Foundation;
	razli�ice 2 ali (po va�i izbiri) katere koli poznej�e razli�ice.

	Ta program se raz�irja v upanju, da bo uporaben, vendar brez kakr�ne
	koli garancije, vklju�no z implicitno garancijo o prodajnosti ali
	primernosti za dolo�en namen. Avtor v nobenem primeru ne bo
	odgovoren za kakr�no koli �kodo, povezano z uporabo tega programa.
	Za ve� podrobnosti glejte licenco GNU General Public License.

	S tem programom bi morali prejeti kopijo licence GNU General Public
	License; �e je niste, pi�ite na naslov Free Software Foundation,
	Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

2.  FUNKCIJE IN SINTAKSA UPORABE

	Program MODE opravlja �est lo�enih funkcij, ki so opisane spodaj.

2.1.  NASTAVITEV VIDEO NA�INA IN �TEVILA ZASLONSKIH VRSTIC

	MODE omogo�a nastavitev video na�ina na enega od petih na�inov.
	Sintaksa je:

	MODE Videona�in[,Vrstice]

	Na�ini so:

	MONO	Monokromatski na�in, kot se uporablja pri karticah MDA in
		Hercules, emuliran pa je tudi na karticah EGA in VGA. Ta
		na�in je edini, ki privzeto omogo�a pod�rtovanje znakov
		na zaslonu. Tega na�ina ni mogo�e izbrati na grafi�ni kartici CGA.

	BW40	40-stolp�ni na�in z zatrto barvo. Ta na�in je specifi�en za
		kartice CGA in omogo�a prikaz 40 stolpcev in 25 vrstic.
		Informacije o barvah v kompozitnem video signalu s kartice CGA
		so izklopljene, tako da je prikaz �rno-bel na kompozitnem
		barvnem monitorju s �estnajstimi odtenki sive.
		�e je ta na�in izbran na kartici EGA ali VGA ali na kartici
		CGA, ki ni priklju�ena na televizor ali kompozitni monitor,
		bo videti enako kot na�in CO40 (barva ne bo zatrta). Tega
		na�ina ni mogo�e izbrati na karticah MDA in Hercules.

	BW80	80-stolp�ni na�in z zatrto barvo. Ta na�in je prav tako
		specifi�en za kartice CGA in je enak kot BW40, le da ima 80
		stolpcev. Tega na�ina ni mogo�e izbrati na karticah MDA in Hercules.

	CO40	40-stolp�ni barvni na�in. Ta na�in omogo�a barvni prikaz s 40
		stolpci in 25 vrsticami. Podpirajo ga adapterji CGA, EGA in
		VGA, ne pa tudi kartice MDA in Hercules.

	CO80	80-stolp�ni barvni na�in. Ta na�in omogo�a prikaz z 80 stolpci
		in 25 vrsticami in je obi�ajen na�in prikaza za kartice CGA,
		EGA in VGA. Kartice MDA in Hercules ga ne podpirajo. Na
		karticah EGA ta na�in podpira tudi razli�ico s 43 vrsticami,
		na karticah VGA pa sta podprti razli�ici s 43 in 50 vrsticami.

		Na�ina s 43 in 50 vrsticami lahko izberete tako, da v ukazni
		vrstici MODE za CO80 navedete ",43" ali ",50". �e ta parameter
		ni naveden, bo uporabljena privzeta vrednost 25 vrstic.

	Ko je video na�in nastavljen, ostane v veljavi, dokler ga ne spremeni
	ukaz MODE ali program. Video na�in ni trajno zaklenjen - programi
	lahko poljubno spreminjajo video na�ine.

2.2.  KONFIGURACIJA PARAMETROV SERIJSKIH VRAT

	MODE omogo�a konfiguracijo komunikacijskih parametrov serijskih vrat.
	Sintaksa je:

	MODE COMn:r,p,d,s

	n	Dolo�a, katera serijska vrata naj bodo konfigurirana, v
		obsegu od 1 do 4. �e serijska vrata ne obstajajo, MODE
		javi napako.

	r	Dolo�a hitrost v bitih na sekundo (baud rate). Vrednosti so:
		50, 110, 150, 300, 600, 1200, 2400, 4800, 9600, 14400,
		19200, 28800, 38400, 57600 in 115200.

		Vrednosti 1200, 2400, 4800 in 9600 lahko skraj�ate na 12, 24,
		48 oziroma 96. Vi�je hitrosti lahko skraj�ate na njihovi prvi
		dve ali tri �tevilke. 115200 lahko skraj�ate na 115 ali 1152.

	p	Dolo�a vrsto paritete. Vrednosti so:

		E = Soda pariteta (Even)
		O = Liha pariteta (Odd)
		N = Brez paritete (None)

	d	Dolo�a �tevilo podatkovnih bitov. Dovoljene vrednosti so 5, 6, 7
	in 8.

	s	Dolo�a �tevilo stop bitov. To je lahko 1 ali 2. �e se uporabita
		2 stop bita s 5 podatkovnimi biti, bodo serijska vrata
		dejansko generirala in preverjala 1 1/2 stop bita.

	Nastavitve serijskih vrat ostanejo v veljavi, dokler jih ne spremeni
	ukaz MODE ali program. Nastavitve niso trajno zaklenjene.

2.3.  PREUSMERITEV VZPOREDNIH VRAT IN NESKON�NE PONOVITVE

	MODE omogo�a preusmeritev izhoda vzporednih (LPT) vrat na serijska
	(COM) vrata, na NUL (tj. nikamor), in lahko tudi neskon�no ponavlja
	poskuse, �e se periferna naprava ne odziva.

	Te funkcije izvaja reziden�ni del programa MODE, ki se po potrebi
	samodejno namesti.

	Sintaksa je:

	MODE LPTn:P		Neskon�na �asovna omejitev na vzporednih vratih
	MODE LPTn:=COMx		Preusmeritev izhoda tiskalnika na vrata COM
	MODE LPTn:=NUL:		Preusmeritev izhoda tiskalnika na NUL
	MODE LPTn:		Prekli�i preusmeritev in neskon�no omejitev

	Funkcija LPTn:P dolo�a neskon�no ponavljanje ob �asovni omejitvi. �e
	je omogo�ena, bo MODE nenehno posku�al poslati podatke, �e se
	tiskalnik ne odziva. Sicer bo po dolo�enem �asu (pribli�no pol minute)
	javljena napaka pri pisanju.

	Funkciji LPTn:=COMx in LPTn:=NUL: dolo�ata preusmeritev izhoda tiskalnika.
	Katera koli vzporedna vrata (tudi neobstoje�a) se lahko preusmerijo na
	katera koli obstoje�a serijska vrata ali na NUL. To je uporabno, �e
	imate serijski tiskalnik ali �e tiskalnika nimate in �elite prepre�iti
	zamrznitev ra�unalnika ob poskusu tiskanja.

	Ukaz MODE LPTn: prekli�e preusmeritev in vrne vrata v normalno stanje.

2.4.  PARKIRANJE TRDEGA DISKA (PARK)

	MODE parkira trdi disk ali diske (le prva dva fizi�na diska v sistemu),
	bodisi takoj bodisi po dolo�enem �asu neaktivnosti.

	�asovno parkiranje izvaja reziden�ni del programa MODE.

	Sintaksa je:

	MODE PARK			Parkiraj zdaj
	MODE PARK,minute[:sekunde]	Parkiraj po neaktivnosti diska

	Funkcija PARK takoj parkira diske in po�aka, da izklopite ra�unalnik.
	Lahko pritisnete tudi Ctrl-C za vrnitev v DOS.

	Funkcija PARK,minute[:sekunde] parkira diske po dolo�enem �asu
	neaktivnosti (do 50 minut). �e imate dva fizi�na diska, se oba
	obravnavata lo�eno.

	�asovno parkiranje ni mogo�e izklopiti - za odstranitev morate
	ponovno zagnati ra�unalnik. Ta funkcija je uporabna predvsem za
	starej�e stroje. Sodobni diski se ob izklopu parkirajo samodejno.

2.5.  FUNKCIJE TYPEMATIC (PONAVLJANJE TIPKOVNICE)

	MODE omogo�a nastavitev za�etne zakasnitve in hitrosti ponavljanja
	tipk ter njihovo poljubno zaklepanje.

	Zaklepanje izvaja reziden�ni del programa MODE.

	Sintaksa je:

	MODE DELAY=d RATE=r		Nastavi parametre
	MODE DELAY=d RATE=r LOCK	Nastavi in zakleni parametre

	d	Dolo�a za�etno zakasnitev (1 do 4), od 1/4 sekunde (1) do
		ene sekunde (4).

	r	Dolo�a hitrost ponavljanja (1 do 32), od dveh ponovitev na
		sekundo (1) do 30 ponovitev na sekundo (32).

	LOCK	Dolo�a, da morajo biti parametri zaklenjeni. Nato jih je
		mogo�e spremeniti le z ukazom MODE, ne pa z drugimi programi.
		To je uporabno, ker nekateri programi spreminjajo nastavitve
		brez dovoljenja.

	Navesti je treba oba parametra DELAY in RATE. MODE sprejme ukaze
	ne glede na to, ali jih stroj dejansko podpira.

2.6.  FUNKCIJE SWITCHAR

	MODE lahko prika�e in nastavi znak za stikalo DOS (switchar). Privzeti
	znak je po�evnica '/'. To je znak, ki uvaja parametre ukazov, npr. /P
	pri ukazu DIR. Obi�ajno se switchar lahko spremeni v vezaj '-'.
	Switchar je nedokumentirana funkcija DOS, ki jo pravilno podpira le
	malo programov.

	Sintaksa je:

	MODE SWITCHAR			Prika�i trenutni switchar
	MODE SWITCHAR=x			Nastavi switchar na znak x
	MODE SWITCHAR=n			Nastavi switchar na vrednost ASCII n

2.7.  FUNKCIJE MODIFIKATORJEV (SHIFT STATE)

	MODE lahko spreminja stanja Caps Lock, Num Lock in Scroll Lock. Te
	funkcije ne smete uporabljati na strojih z originalnimi tipkovnicami
	PC ali XT, ker indikatorskih lu�k na njih ni mogo�e nadzorovati iz
	ra�unalnika in bi pri�lo do neskladja s stanjem v ra�unalniku.

	Mo�nosti so:

		CAPSLOCK=ON	CAPSLOCK=OFF
		NUMLOCK=ON	NUMLOCK=OFF
		SCRLOCK=ON	SCRLOCK=OFF

	Uporabite lahko katero koli kombinacijo, ki ni v konfliktu. SCRLOCK
	se lahko zapi�e tudi kot SCROLLLOCK.

3.  SPLO�NE INFORMACIJE

	Parametri MODE ne razlikujejo med velikimi in malimi �rkami. MODE
	v enem klicu obdela le en ukaz.

	Sporo�ila o napakah se po�iljajo na StdErr. Informativna sporo�ila
	na standardni izhod (lahko se preusmerijo na NUL:).

	Errorlevels, ki jih vra�a program MODE:

	0	Brez napake
	115	Serijska vrata ne obstajajo
	117	Ni najden noben trdi disk za parkiranje
	118	Video na�in na tem stroju ni podprt
	162	Ni dovolj pomnilnika (MODE potrebuje pribli�no 6K)
	241	Parameter zunaj obsega
	242	Na�ina s 43 ali 50 vrsticami sta mo�na le s CO80
	243	Neznana hitrost prenosa
	244	Navesti je treba tako DELAY= kot RATE=
	246	Podanih je bilo ve� ukazov ali vrst ukazov
	255	Napa�na sintaksa

	�e najdete napako, kontaktirajte avtorja (podatki v razdelku 1).

4.  PRIMERI UPORABE

	Primer v AUTOEXEC.BAT:

	mode co80,43			>nul:
	mode com1:96,n,8,1		>nul:
	mode com2:19,n,8,1		>nul:
	mode com3:24,n,8,1		>nul:
	mode lpt1:=com2			>nul:
	mode lpt1:p			>nul:
	mode lpt2:=nul:			>nul:
	mode lpt3:=nul:			>nul:
	mode park,0:30			>nul:
	mode delay=1 rate=32 lock	>nul:
	mode switchar=-			>nul:
	mode numlock=off		>nul:

	To zaporedje nastavi 43-vrsti�ni barvni na�in, konfigurira COM1-3,
	preusmeri LPT1 na COM2, nastavi �asovno parkiranje diska na 30 s,
	nastavi tipkovnico in spremeni switchar na '-'.

				   ----//----
