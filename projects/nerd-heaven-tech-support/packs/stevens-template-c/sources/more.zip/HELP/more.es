Language: spanish
File ending: es
Codepage: 858
This translation was made by Google Gemini.
Please help the FreeDOS group to improve it.

Este es el archivo de ayuda para MORE:

MORE: Muestra el contenido de un archivo de texto pantalla a pantalla.
Este es software libre y puede redistribuirlo bajo la licencia
GNU GPL; consulte el archivo COPYING para m�s detalles.

Uso:
comando | MORE
MORE archivo..
MORE < archivo

Teclas disponibles (al ver un archivo):
N n = Siguiente archivo
Q q = Salir del programa

