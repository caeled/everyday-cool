# Collection copy

Source supplied by Steven Powell on 6 October 2026. This independent copy is maintained inside Everyday Cool. Source file SHA-256 hashes are recorded in ../../provenance/a-library.json; no original Git commit is claimed.

Local changes to `a-library.html`: added collection navigation and license/download links; added a From Everyday Cool link to The Radio Room (17 November 2026, the reciprocal of that room's link here); labeled the retired World Factbook accurately; refreshed the British Library address; clarified resource-specific rights and internet requirements. The original shelf organization is preserved.

Documentation update (20 November 2026): at Steven Powell's direction, `a-library.html` gained a professional Documentation & source panel with the room README, GitHub source, sources and limitations, workshop download, collection documentation index, and curator profile link. Changed files: `a-library.html`, `COLLECTION.md`. The addition is documentation and navigation only; no lesson content or workshop behaviour was changed.

Shelf update (20 November 2026): at Steven Powell's direction, eight references drawn from the newer rooms — Everyday Time, Everyday Sound, Everyday Light, Everyday Math, and Everyday Food — were shelved in `a-library.html`, each checked live on the day: Camp Cookery (1910) (Books); time.gov and Math is Fun (Reference); Explore Sound and The Physics Classroom (Science); Eat The Weeds, the North American Sundial Society, and The Mutopia Project (Earth, sky, and making). The shelf count in `README.md` was corrected from 35 to 43. Changed files: `a-library.html`, `README.md`, `COLLECTION.md`. The original shelf organization is unchanged; entries were added, none moved or removed.
