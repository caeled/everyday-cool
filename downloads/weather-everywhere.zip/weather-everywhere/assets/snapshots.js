window.WEATHER_SNAPSHOTS = {};
