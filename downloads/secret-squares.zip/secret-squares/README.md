# Secret Squares

An Everyday Cool workshop by Steven Powell. Make real QR codes and barcodes, investigate information, and share an invented secret. Free, portable, and built for curious kids and adults.

[Open the workshop](https://caeled.github.io/secret-squares/) · [Open project on GitHub](https://github.com/caeled/secret-squares) · [Download the complete ZIP](https://github.com/caeled/secret-squares/archive/refs/heads/main.zip)

## Start

Open **index.html** in a modern browser, or double-click **Launch.cmd** on Windows. Keep the complete folder together. No installation, account, API key, external font, server upload, or framework is needed for the core workshop.

Cryptography and packet checksums need Web Crypto. Modern browsers may allow it for local files; if yours does not, run **Serve.cmd**, which uses Python 3 already installed to serve only this folder at localhost:8003. A hosted copy must use HTTPS. Do not disable browser security settings. Close the server window to stop it.

## Nine rooms

1. **Make a code:** messages, URLs, Unicode, four correction levels, three dark inks, downloadable SVG/PNG, destination preview, and local image decoding.
2. **Inside the squares:** actual structural reservation map, finder/timing/format/alignment regions, all eight masks, and the encoding pipeline. Colored anatomy views are diagrams; plain views scan.
3. **Damage lab:** cover actual modules and test recovery with a real local QR decoder. Compare locations and correction levels without pretending image-area coverage has a guaranteed threshold.
4. **Bytes & packing:** code points, UTF-8, binary bytes, real gzip, and base64url overhead. Gzip is measured separately; ordinary studio codes do not automatically compress text.
5. **Secret messages:** AES-256-GCM with fresh random nonces and random shared keys; hybrid RSA-OAEP/SHA-256 public-key experiments. Export/import receiving keys to try two devices. Public QR codes never include private/shared secret keys.
6. **Transfer station:** custom numbered text packets with a whole-message SHA-256 checksum, reverse ordering, duplicate handling, and missing-piece detection. Not QR Structured Append. The station also hosts the room's game, **Pass It On** (`pass-it-on.html`): a message crosses a noisy channel while you climb from naked digits to a check digit, a parity grid, and a budget of shields — with its back-door lesson (`pass-it-on-lesson.html`) on detection, correction, and their honest limits.
7. **Barcodes:** make a real UPC-A from 11 digits (the bench adds the check digit) or all 12 (it checks your math); bar anatomy and parity, the check digit worked by hand, and a pocket catalog that teaches the real lesson — the name and price live in a catalog, not in the bars. An optional labeled link leads out to Open Food Facts; the workshop itself still sends nothing. A QR code under the room's banner opens the room on a phone, so a barcode made on one screen can meet a scanner on another.
8. **Field missions:** nine experiments and a downloadable printable treasure-hunt sheet.
9. **Go deeper:** primary sources, portable guide, scientific notes, and an ASL fingerspelling introduction with real hand-position references and a real signing demonstration. ASL is a language with its own grammar; fingerspelling is one part of it.

**Also in the Transfer Station:** **Dead Drop** (`dead-drop.html`) — Steven Powell's own sneakernet workbench, a single offline file with four channels for passing a note across an air gap: image LSB steganography, QR, Morse, and numbers stations, with its back-door lesson (`dead-drop-lesson.html`) on what each channel actually does and the audit that drove all four of them. Its built-in self-test passes 4/4, with 50 independent checks besides.

**Cross-room feature — Morse:** code-sending is this room's subject, so the Transfer Station also features the Morse sender — but the sender itself lives in the Radio Room (`../radio-room/morse.html`, with its lesson at `../radio-room/morse-lesson.html`), on the same table and at the same timing as its sibling Skip.

## Compatibility

The QR studio and local jsQR reader work offline. For other phones, scan the generated code at a suitable size with its white border visible. Emoji codes declare UTF-8 with ECI 26; support differs between scanners. Downloads require browser download permissions. Uploaded images are decoded locally and never uploaded to a server. The reader accepts PNG, JPEG, and WebP, up to 8 MB; crop unusually large images first.

**ASL discovery:** the original mini-lesson works offline. Its optional reference chart and video load only after you press their buttons. Online media remains with Lifeprint / ASL University and YouTube. Run **tools/Get-ASL-Reference.ps1** if you want a chart saved for personal-device or classroom use. The chart is copyright William Vicars and is not covered by our free code/content licenses; review its permission terms before redistribution. No AI-generated signing is used.

Web Crypto requires browser support and a secure context. Gzip requires CompressionStream. If either is unavailable, that bench reports the limitation; other benches remain available. The modern JavaScript QR build targets current browsers. No camera permission is requested: scanning here uses image uploads or the generated canvas.

## Privacy and learning

No analytics, telemetry, external scripts, automatic network calls, or automatic secret persistence. Secret keys and messages live in page memory until cleared/refreshed. Downloads are explicit and remain on your device. Exported secret-key files are **unencrypted**. Clearing page fields cannot guarantee secure erasure of browser memory or delete downloads.

Use made-up messages for cryptography experiments. Established algorithms do not make this an audited secure messaging product. The workshop does not authenticate senders, verify a recipient’s identity automatically, protect an already-compromised device, or hide metadata. Confirm public-key fingerprints separately through a trusted channel. See **SCIENCE.md**.

## Teach it

Try a 45-minute session: make and scan a clue (10 minutes), inspect the pattern and damage it (10), compare bytes and gzip (10), then exchange an encrypted practice message (15). For younger learners, stop after the clue and damage experiment. For advanced learners, inspect the readable source and try a two-device public-key exchange.

## Verify and package

With Node.js and Python installed:

```
node --test tests/core.test.cjs
python tests/check-package.py
```

Run **tools/Build-Package.ps1** to rebuild the USB ZIP. No runtime dependencies beyond your browser; Node and Python are development/test conveniences. Both QR libraries are bundled. Source TypeScript is retained, but a build is not required.

## Licenses

Original code/helpers: MIT, copyright Steven Powell 2026. Original educational content: CC BY 4.0. Project Nayuki’s QR encoder: MIT. jsQR: Apache 2.0. Keep applicable notices when sharing; see **THIRD-PARTY.md** and vendor license files. External research pages retain their own terms.
