# Sources & limitations

## Bundled material

All lesson/Help text and code are original work written for this workshop (code MIT, lessons CC BY 4.0). The banner image is AI-generated art made for this room. No third-party code, fonts, or data files are bundled in this folder.

## Data sources (facts, not files)

- **Additive and subtractive mixing** — the RGB additive system and the CMY subtractive system are the standard colour models, as set out in the Wikipedia Additive color and Subtractive color articles on the shelf and in The Physics Classroom's Light and Color course. The paint bench's pigment profiles are a simplified reflectance model built for this room: each pigment is assigned the share of red, green, and blue light it reflects at full strength (cyan 5/75/85%, magenta 85/5/75%, yellow 90/85/5%), partial amounts lean from white paper toward those profiles, and the three multiply. The profiles were chosen to reproduce the textbook behaviours — each pigment swallowing its complementary channel, pairs mixing to the expected hues, and the full mixture leaking to a warm near-black (≈ rgb(10, 8, 8)) instead of a true black, as real CMY inks do; that real-world leak is the documented reason process printing adds a black (K) plate.
- **Colour theory and the wheel** — the twelve-hue wheel and the chord families (complementary, analogous, triadic, split-complementary) are the standard colour-theory scheme descending from Newton's colour circle, as set out in the Wikipedia Color theory and Color wheel articles on the shelf. The angles are the definitions: complementary hues sit 180° apart, triadic hues at 120° steps. The pairing with the circle of fifths is this collection's own framing, made at Steven Powell's direction (Sound carries music theory; Light carries colour theory), and the geometry it rests on — twelve points on a circle, distances as recipes — is exact in both rooms.
- **The thin lens** — the lens equation 1/f = 1/do + 1/di, the magnification m = −di/do, the sign conventions (negative di = virtual image), and the three principal rays are the standard geometrical-optics treatment, as in the Wikipedia Thin lens article and OpenStax University Physics Volume 3, both on the shelf.
- **Rayleigh scattering** — the 1/λ⁴ law and its consequences (blue sky, red sunset, the ≈4.35 ratio between 450 nm and 650 nm scattering) are the standard result, as in the Wikipedia Rayleigh scattering article and HyperPhysics' blue-sky page, both on the shelf. The bench's sun and sky colours come from a three-sample-wavelength extinction model built for this room (samples at 650/550/450 nm, one extinction coefficient of 0.10 per air mass, air mass ≈ 1/sin(altitude) capped at 40) — a teaching model chosen to show the rule's direction and rough size, not an atmospheric radiative-transfer calculation.
- **Solar position and shadows** — altitude and azimuth use the standard spherical-astronomy formulas (in terms of latitude, declination, and hour angle); the solstice/equinox declinations (±23.44°, 0) are the conventional values; shadow length = height ÷ tan(altitude) is elementary trigonometry. The same geometry underlies Everyday Time's sundial bench, whose hour-line rule is cited there. The Survival Guide's shadow-stick method is the field version of the same shadow.
- **The spectrum** — the visible band (≈380–750 nm), the frequency relation f = c/λ with c = 299,792,458 m/s exact by definition since 1983, and the infrared/ultraviolet facts (remote controls and thermal imaging; sunburn, bee vision, fluorescence) are the standard published material, as in the Wikipedia Electromagnetic spectrum article on the shelf. The wavelength-to-colour mapping is the usual hue-walk approximation, dimmed at the band's ends where the eye's sensitivity fades; it suggests spectral colours, it does not reproduce them.

## The game — Laser & Mirrors

`laser-mirrors.html` is an original Everyday Cool game built by Muse on 20 November 2026 for this room: seven puzzles in which the player rotates 45° mirrors to bounce a laser beam onto every target, the reflection rule — angle in equals angle out — as the whole mechanic. It is cross-listed on the Physics Game Table in Everyday Physics. Like the benches, it makes no network calls. Its simplifications, stated plainly:

- The mirrors are **two-sided 45° diagonals**: the beam reflects off either face, the player flips each mirror between its two diagonal orientations, and there are no single-sided mirrors.
- **Targets are pass-through sensors**: the beam lights a target and continues past it, which is what lets one beam thread several targets on a single path.
- **Glass blocks pass the beam straight through, with no bending.** Real glass refracts — that is the lens bench's story, told in this room above, not the game's.
- The beam travels a square grid, so **every turn is an exact 90°** — true to 45° mirror geometry, but there are no free-angle mirrors.

## Linked, not loaded (each opens in a new tab, under its own terms)

OpenStax University Physics Volume 3 (openstax.org) · The Physics Classroom (physicsclassroom.com) · HyperPhysics, Georgia State University (gsu.edu) · Wikipedia: Rayleigh scattering, Thin lens, Additive color, Subtractive color, Color theory, Color wheel, Electromagnetic spectrum (wikipedia.org). Every link was checked live on 20 November 2026 and returned HTTP 200 to a browser-style request.

## Nothing is called at view time

This page makes no network calls at all: the benches run entirely in the browser from code in this folder. The shelf links are only followed when a visitor presses one.

## Limitations

The paint bench simulates pigment with the reflectance model described above; it is not a spectral pigment simulator, and real paints — which also scatter, dry darker, and vary by brand — will differ from its swatches in detail while agreeing in direction. The lens bench is the thin-lens idealisation: no aberrations, no thickness, no multi-element corrections. The sky bench assumes clean air and three sample wavelengths; dust, smoke, humidity, and clouds all move real sunsets off its swatches. The shadow bench keeps solar time and the four season markers' declinations rather than a daily ephemeris. The spectrum swatches are approximations, and the infrared and ultraviolet are described, never displayed — no screen can show them. Descriptions were written on 20 November 2026; each linked site's own pages are the authority.
