# Collection origin

Original Everyday Cool workshop, authorized by the curator. Authored by Steven Powell from a design brief prepared by Copilot (31 October 2026); the brief is preserved in full as `DESIGN.md` in this folder. Implemented by Muse (31 October 2026) as a new collection workshop — it is not a copy of an upstream project, and no separate maintained original exists. The workshop source in this folder is the maintained original.

No imported third-party code or media. All statements, products, scenarios, and charts are fictional; no personal data, credentials, or real product claims are published. The workshop page sends nothing, stores nothing, and runs entirely offline.

Banner added November 15, 2026: decisions-banner.jpg (AI/robots theme), part of the collection-wide banner pass.

Documentation update (20 November 2026): at Steven Powell's direction, `index.html` gained a professional Documentation & source panel with the room README, GitHub source, sources and limitations, workshop download, collection documentation index, and curator profile link. Changed files: `index.html`, `COLLECTION.md`. The addition is documentation and navigation only; no lesson content or workshop behaviour was changed.

Game (21 November 2026): at Steven Powell's direction, the workshop gained its first game — `the-boring-bet-wins.html`, **The Boring Bet Wins**, seated in the probability room: three doors with their expected values printed on them (the boring bet at exactly +13/5, the fair coin at 0, the flashy wheel at −5/2), free rounds with an actual-vs-expected ledger, a 30-round challenge that only the boring line reliably finishes (93.4% over 500 seeds), and a Long Run simulator whose measured results the lesson prints: flashy ruins 100 of 100 runs, the boring median climbs 500 to 3,114, the fair median sits exactly on its start. `the-boring-bet-wins-lesson.html` is its back door (the three EVs by hand, variance, the law of large numbers, gambler's ruin), opened from inside the game by a Lesson pop-up. `index.html` gained a game card in the probability room. The game also visits the Physics Game Table, the Arcade shelf, and both lesson shelves. Changed files: `the-boring-bet-wins.html`, `the-boring-bet-wins-lesson.html`, `index.html`, `README.md`, `COLLECTION.md`.


Forum link (26 November 2026): `index.html` gained the collection's Join our Forum line (Steven's Google Group — anyone may ask to join, members post), the feedback door he asked to have everywhere.
