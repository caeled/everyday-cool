# Collection origin

Original Everyday Cool workshop, added 15 November 2026 at Steven Powell's request. He chose the Map Room to round out the collection hub ("I need one more everyday cool to fill out/balance number of cards as they display") and asked for "a location button that focuses a displayed map on your current location (or enter zip)". The teaching section's title, "Useful Maps", is his. Built by Muse (AI assistant) in the main chat and added directly to the collection at his direction; this folder is the maintained original, and there is no upstream copy.

The live map is OpenStreetMap data drawn by the Leaflet library, both loaded from their public services at view time (nothing is vendored). Find-me uses the browser's geolocation; ZIP and town searches use OpenStreetMap's Nominatim service. The page footer discloses all of this in plain language.

The compass-rose trainer's rules live in `compass.js` (no DOM), checked by `test.cjs`.

Build a Map was added the same day, also at Steven's direction: CSV pin files plotted as markers (with `group` and `close` columns connecting points into paths and closed shapes — his refinement), PDF coordinate hunting via pdf.js, click-to-add draggable pins with a measured trail, CSV export, and printing. Its rules live in `maptools.js`, also checked by `test.cjs`, including a test that reads the shipped `sample-square.csv` itself: four compass-named corners around Defiance (centre 41.2845, -84.3558, ±0.01°) that must come back as one closed shape, corners connected in order. pdf.js 3.11.174 and its worker were verified live on unpkg (HTTP 200) on 15 November 2026.

Banner: `map-banner.jpg`, AI-generated watercolor to Steven's own concept — robots pulling maps off a shelf, some referencing a digital map on a glowing screen, others reading paper maps — generated 15 November 2026 as part of adding this room, in the style of the collection's other banners.

The Keep Going links were each verified live on 15 November 2026 (HTTP 200 to a browser user agent): openstreetmap.org, apps.nationalmap.gov/viewer, the USGS National Map program page, and compassdude.com. The Leaflet 1.9.4 files on unpkg were likewise verified (HTTP 200, and their published SRI hashes recomputed and matched locally before being pinned in `index.html`). USGS topoView (ngmdb.usgs.gov/topoview) answered 403 to a scripted check, so the National Map viewer is linked instead. Nominatim was exercised directly: ZIP 43512 resolves to Defiance, Ohio, which is the map's default view.

Local changes to imported files: none (no files were imported; all files originate here).

Documentation update (20 November 2026): at Steven Powell's direction, `index.html` gained a professional Documentation & source panel with the room README, GitHub source, sources and limitations, workshop download, collection documentation index, and curator profile link. Changed files: `index.html`, `COLLECTION.md`. The addition is documentation and navigation only; no lesson content or workshop behaviour was changed.

Game (21 November 2026): at Steven Powell's direction, the room gained its first game — `go-thataway.html`, **Go Thataway**: five fields navigated by bearing and pace count under an honest drift model (a per-level veer plus a seeded wandering heading, integrated step by step), where walking a briefed bearing open-loop lands wide and a fix off a landmark — or a handrail like the creek — corrects the way in, in the stance of the Survival Guide's navigation card: not precision, "go thataway — and you get there." The proof navigator plays with only the player's information (a believed position, corrected by fixes and waypoint arrivals): it reaches every level, and misses the two long levels with fixes disabled (17.7 m and 24.1 m wide). `go-thataway-lesson.html` is its back door — bearings and back bearings, pace calibration, the drift arithmetic, aiming off, declination named honestly — opened from inside the game by a Lesson pop-up. `index.html` gained a game card in the Useful Maps grid. The game also visits the Physics Game Table, the Arcade shelf, and both lesson shelves. Changed files: `go-thataway.html`, `go-thataway-lesson.html`, `index.html`, `README.md`, `COLLECTION.md`.


Forum link (26 November 2026): `index.html` gained the collection's Join our Forum line (Steven's Google Group — anyone may ask to join, members post), the feedback door he asked to have everywhere.

## Screen sizes (2026-11-27 evening)

`go-thataway.html` gained through the across-the-board rollout: Go Thataway gained SIZE / FULL SCREEN / POP OUT (display only). Audited: the map grows 950 to 1,480 px with zero page errors; its pointer mapping is rect-based, so halves stay honest at scale.. The choice is remembered per page; full-screen buttons call the standard API and Steven's click is their receipt.

